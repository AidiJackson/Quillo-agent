
  # Quillo AI Web App UI

  This is a code bundle for Quillo AI Web App UI. The original project is available at https://www.figma.com/design/N4PvCfDPRO0hChc7yCBtCc/Quillo-AI-Web-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  